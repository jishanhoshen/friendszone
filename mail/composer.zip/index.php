<?php 
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try{
    // $mail->SMTPDebug = 2;                                                   // Enable verbose debug output
    $mail->isSMTP();                                                        // Set mailer to use SMTP
    $mail->Host       = 'smtp-pulse.com;';                                  // Specify main SMTP server
    $mail->SMTPAuth   = true;                                               // Enable SMTP authentication
    $mail->Username   = 'jishanhoshenjibon@gmail.com';                      // SMTP username
    $mail->Password   = 'WQoMScpRgEYNjQ';                                   // SMTP password
    $mail->SMTPSecure = 'tls';                                              // Enable TLS encryption, 'ssl' also accepted
    $mail->Port       = 587;                                                // TCP port to connect to
    
    $mail->setFrom('info@dream-creators.com', 'Dream Creators Information');// Set sender of the mail
    $mail->addAddress('maryeasleyadkins@gmail.com');                       // Add a recipient
    $mail->addAddress('maryeasleyadkins@gmail.com', 'Hello Mary');         // Name is optional
    
    $mail->isHTML(true);                                  
    $mail->Subject = 'test mail';
    $mail->Body    = 'mail from phpmailer . using <strong>SMTP</strong> HTML message body in <b>bold</b>!';
    $mail->AltBody = 'Body in plain text for non-HTML mail clients';
    
    $mail->send();
    echo "Mail has been sent successfully!";
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}